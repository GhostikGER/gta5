require("login.js");
require('vspawner');
require('indicators');
require('speedometer');
require('charcreator');
require('VehManager');

mp.gui.chat.show(true);
mp.gui.chat.activate(false);