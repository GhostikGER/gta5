require("login.js");
require('vspawner')

mp.gui.chat.show(true);
mp.gui.chat.activate(false);